/*
 * karte.js - map module of the CSS 3D variant: builds the 3D map of the Quadrate from ordinary HTML
 * elements, which css/karte.css turns in 3D, and offers window.Karte (web/ARCHITECTURE.md).      [V2]
 *
 * How it fits in:
 * - js/data/karte-daten.js (window.KARTE_DATEN, made by tools/export_karte_css3d.py) holds the geometry:
 *   stage, camera, the tilted ground plate, and per Quadrat its roofs, walls, label and growth.
 *   This file only creates the elements and writes the numbers into CSS custom properties.
 * - The page (js/app.js) only uses the interface window.Karte:
 *     Karte.init(container, { onSelect(code, byKeyboard), onHover(code | null) })  builds the map
 *     Karte.faerben(map | null, texts)  { "G2": "#D23F27", ... } colours whole buildings; null = default;
 *                                       texts { "G2": "9 geöffnet" } go into the accessible names
 *     Karte.waehlen(code | null)        selects a Quadrat (it grows and is lit from below); null = none
 *     Karte.markieren(codes)            pins on Quadrate with saved places; [] removes all pins;
 *                                       { "G2": "essen" } colours a pin like its category (2026-10-13)
 *     Karte.stimmung(name)              time-of-day mood: "tag", "aufgang", "untergang" or "nacht"
 *                                       (js/filter.js chooses it from the filter time); the change fades
 *                                       softly in 0.9 s like in Version 4, but keeps the tilt of the map
 *                                       (Version 6, see stimmung() and fadeOut())
 *     Karte.codes()                     array of all 146 codes
 *   Without JavaScript the page shows the static image img/karte-statisch.png instead of this map.
 * Classic script without modules, so the page also works by double-click (file://).
 */
(function () {
    "use strict";
    // Everything lives inside this function so that our variables do not collide with other scripts.
    // Only window.Karte (at the end) is visible from outside.

    // Smallest scale of the map. Below it the map frame scrolls sideways (phones), so the codes stay readable.
    var MIN_SCALE = 0.5;
    var TEXT_DARK = "#2b2d31";        // dark code text, the same as --map-text-dark in css/karte.css
    var MAX_PINS = 3;                 // at most 3 pins on one Quadrat, one per saved place (2026-10-14)
    var PIN_GAP = 20;                 // distance between two pins side by side, in pixels of the map plane

    var data = null;                  // window.KARTE_DATEN
    var frame = null;                 // div.map-scroll: may scroll sideways on narrow screens
    var sizer = null;                 // div.map-sizer: has the size of the scaled stage
    var stage = null;                 // div.map-stage: the 3D stage with the perspective
    var plane = null;                 // div.map-plane: the tilted ground plate
    var pools = null;                 // div.map-pools: the glows on the ground, under all buildings
    var elementsByCode = {};          // code -> div.map-block
    var poolsByCode = {};             // code -> div.map-pool (glow under the selected Quadrat)
    var entriesByCode = {};           // code -> entry of KARTE_DATEN.quadrate
    var selected = null;              // code of the selected Quadrat or null
    var handlers = {};                // functions of the page: onSelect, onHover
    var countTexts = {};              // code -> text such as "9 geöffnet" from Karte.faerben()
    var pinned = {};                  // code -> true for Quadrate with a pin
    var pinCategory = {};             // code -> list of categories of its pins (null = red), 2026-10-13/14
    var resizeObserver = null;        // rescales the map when the frame changes its width
    var walls = [];                   // every wall: { element, angle }, for the light of the moods
    var mood = null;                  // current time-of-day mood, e.g. "tag"
    var moodsGlide = false;           // false at the start: the first mood appears at once, later ones glide
    var ghost = null;                 // div.map-ghost: the fading picture of the old mood, or null (Version 6)
    var ghostTimer = null;            // removes the picture when its fade is over

    // How long the picture of the old mood fades (ms); keep equal to --mood-duration (0.9s) in css/karte.css.
    var FADE_MS = 900;

    // Direction towards the sun (or the moon) per mood, as [east, south] on the map: on the map east is on the
    // right and south at the bottom. Sunrise: from the east; sunset: from the west; day: from the south-west
    // (like the reference images); night: the moon in the west. maxShade = how dark a wall turned away gets.
    var LIGHT = {
        tag: { direction: [-0.55, 0.83], maxShade: 0.3 },
        aufgang: { direction: [1, 0.25], maxShade: 0.45 },
        untergang: { direction: [-1, 0.25], maxShade: 0.45 },
        nacht: { direction: [-0.8, 0.6], maxShade: 0.4 }
    };

    /* ---------------- small helpers ---------------- */

    /** Turns a number into a CSS pixel value: 12 -> "12px". */
    function px(value) {
        return value + "px";
    }

    /** Creates an element (tag, e.g. "div") with a CSS class and appends it to the parent element. */
    function createChild(tag, className, parent) {
        var element = document.createElement(tag);
        element.className = className;
        parent.appendChild(element);
        return element;
    }

    /**
     * Creates one layer per mood (div.mood-layer.mood-layer--tag, --aufgang, ...) in the parent element.
     * css/karte.css gives each layer its colour gradient and shows only the layer of the current mood.
     */
    function createMoodLayers(parent) {
        for (var name in LIGHT) {
            createChild("div", "mood-layer mood-layer--" + name, parent);
        }
    }

    /** Places an element on the plate: box = [left, top, width, height] in plate pixels. */
    function setBox(element, box) {
        element.style.left = px(box[0]);
        element.style.top = px(box[1]);
        element.style.width = px(box[2]);
        element.style.height = px(box[3]);
    }

    /**
     * Stores a footprint as a CSS custom property, e.g. --outline-outer: polygon(1px 2px, ...).
     * css/karte.css uses it for clip-path, so the edge and the roof surface get the shape of the block.
     * points is a list of "x y" points relative to the element.
     */
    function setOutline(element, name, points) {
        element.style.setProperty(name, "polygon(" + points + ")");
    }

    /**
     * Accessible name of a Quadrat: "Quadrat O3"; open squares add their
     * name ("Quadrat G1, Marktplatz"), the filter adds the number of open places ("Quadrat G2, 9 geöffnet")
     * and a Quadrat with a pin adds ", gemerkte Orte".
     */
    function labelText(block) {
        var text = "Quadrat " + block.code;
        if (block.name) {
            text += ", " + block.name;
        }
        if (countTexts[block.code]) {
            text += ", " + countTexts[block.code];
        }
        if (pinned[block.code] === true) {
            text += ", gemerkte Orte";
        }
        return text;
    }

    /** Writes the accessible name of a Quadrat onto its element (see labelText). */
    function updateLabel(code) {
        elementsByCode[code].setAttribute("aria-label", labelText(entriesByCode[code]));
    }

    /* ---------------- building the map ---------------- */

    /**
     * Builds one wall. wall = [x, y, length, angle, darkening]: (x, y) is the corner where the wall starts.
     * The wall's bottom edge must lie on that corner, so the element starts one wall height above it.
     */
    function buildWall(parent, wall, height) {
        var element = createChild("div", "map-wall", parent);
        element.style.left = px(wall[0]);
        element.style.top = px(wall[1] - height);
        element.style.width = px(wall[2]);
        element.style.setProperty("--angle", wall[3] + "deg");
        element.style.setProperty("--shade", wall[4]);
        // every wall starts its lit windows (night, css/karte.css) at its own offset of 0 to 16 px
        element.style.setProperty("--win-x", px((walls.length * 7) % 17));
        walls.push({ element: element, angle: wall[3] });
    }

    /** Builds one building part of a Quadrat: walls, roof with edge and the code on the roof. */
    function buildPart(blockElement, part, code) {
        var partElement = createChild("div", "map-part", blockElement);
        // when selected, the part is scaled around this point (see .is-selected .map-part in karte.css)
        partElement.style.transformOrigin = px(part.zentrum[0]) + " " + px(part.zentrum[1]);
        partElement.style.setProperty("--sx", part.skala[0]);
        partElement.style.setProperty("--sy", part.skala[1]);

        for (var i = 0; i < part.waende.length; i++) {
            buildWall(partElement, part.waende[i], data.hoehen.block);
        }

        var roof = createChild("div", "map-roof", partElement);
        setBox(roof, part.box);
        setOutline(roof, "--outline-outer", part.aussen);
        setOutline(roof, "--outline-inner", part.innen);
        setOutline(roof, "--outline-selected", part.innenAuswahl);
        createChild("div", "map-roof-edge", roof);
        createChild("div", "map-roof-surface", roof);

        var label = createChild("span", "map-code", roof);
        label.textContent = code;
        label.style.left = px(part.schrift[0] - part.box[0]);
        label.style.top = px(part.schrift[1] - part.box[1]);
        label.style.fontSize = px(part.schrift[2]);
        label.style.setProperty("--label-matrix", "matrix(" + part.matrix.join(", ") + ", 0, 0)");
    }

    /** Builds an open square (flat): outline for hover and selection, and an upright sign with code and name. */
    function buildSquare(blockElement, block) {
        var square = createChild("div", "map-square", blockElement);
        setBox(square, block.platz.box);
        setOutline(square, "--outline-outer", block.platz.rand);      // a ring: only the edge of the square
        setOutline(square, "--outline-inner", block.platz.innen);
        createChild("div", "map-square-edge", square);
        createChild("div", "map-square-inner", square);

        // the sign stands on the ground at (x, y) and faces the camera (see .map-sign in karte.css)
        var sign = createChild("div", "map-sign", blockElement);
        sign.style.left = px(block.platz.schrift[0]);
        sign.style.top = px(block.platz.schrift[1]);
        sign.style.setProperty("--sign-scale", block.platz.massstab);
        var text = createChild("span", "map-sign-text", sign);
        text.style.setProperty("--halo", block.platz.halo);
        createChild("span", "map-sign-code", text).textContent = block.code;
        if (block.name) {
            var name = createChild("span", "map-sign-name", text);
            name.textContent = block.name;
            name.style.fontSize = px(block.platz.schrift[3]);
        }
    }

    /** Builds one Quadrat with everything that belongs to it and makes it usable with mouse and keyboard. */
    function buildBlock(block) {
        var blockElement = createChild("div", "map-block", plane);
        blockElement.setAttribute("data-code", block.code);
        blockElement.setAttribute("tabindex", "0");
        blockElement.setAttribute("role", "button");

        // The glow lies in the shared ground layer (div.map-pools), not inside the block: as a flat layer
        // between the buildings it made Safari draw A4 behind B4 and B5 when A4 was selected.
        var lightPool = createChild("div", "map-pool", pools);
        setBox(lightPool, block.licht);
        poolsByCode[block.code] = lightPool;

        if (block.art === "platz") {
            blockElement.classList.add("map-block--open");
            buildSquare(blockElement, block);
        } else {
            for (var i = 0; i < block.teile.length; i++) {
                buildPart(blockElement, block.teile[i], block.code);
            }
        }

        blockElement.addEventListener("click", function () {
            choose(block.code, false);
        });
        blockElement.addEventListener("keydown", function (event) {
            if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();           // the space bar must not scroll the page
                choose(block.code, true);
            }
        });
        // The div.map-block itself has no size (its parts are placed absolutely), so the browser would
        // scroll to the corner of the plate instead of the block. Scroll its roof (or sign) into view.
        blockElement.addEventListener("focus", function () {
            var target = blockElement.querySelector(".map-roof, .map-sign-text");
            if (target) {
                target.scrollIntoView({ block: "nearest", inline: "nearest" });
            }
        });
        blockElement.addEventListener("mouseenter", function () {
            if (handlers.onHover) {
                handlers.onHover(block.code);
            }
        });
        blockElement.addEventListener("mouseleave", function () {
            if (handlers.onHover) {
                handlers.onHover(null);
            }
        });
        return blockElement;
    }

    /** Builds the Schloss: camera-facing walls and the roof picture with the courtyards (not clickable). */
    function buildPalace() {
        var palace = createChild("div", "map-palace", plane);
        palace.setAttribute("aria-hidden", "true");
        for (var i = 0; i < data.schloss.waende.length; i++) {
            buildWall(palace, data.schloss.waende[i], data.hoehen.schloss);
        }
        setBox(createChild("div", "map-palace-roof", palace), data.schloss.box);
    }

    /**
     * Places the upright trees (only the trees that stand close in front of a building; all others are painted
     * into the ground picture) and the Wasserturm.
     */
    function buildTreesAndLandmarks() {
        for (var i = 0; i < data.baeume.length; i++) {
            var tree = createChild("div", "map-tree", plane);
            tree.style.left = px(data.baeume[i][0]);
            tree.style.top = px(data.baeume[i][1]);
        }
        for (var j = 0; j < data.wahrzeichen.length; j++) {
            var landmark = data.wahrzeichen[j];
            var image = createChild("img", "map-landmark", plane);
            image.src = landmark.bild;
            image.alt = landmark.alt;
            setBox(image, landmark.box);
        }
    }

    /**
     * Builds the sky above the city: a light layer over the whole map, the sky band at the top with the stars,
     * the sun and the moon in it. css/karte.css shows or hides them per mood.
     */
    function buildSky() {
        // Sky and light lie in the box around the stage (map-sizer), not in the stage itself (2026-10-14): in the
        // stage the browser sorted them in depth together with the tilted plate, and where the plate came closer,
        // they stopped at a hard edge (a "rectangle" in the picture). The sizer is flat, so nothing cuts them.
        // The sky band is scaled like the stage (css/karte.css), so the sun keeps its place in stage pixels.
        var sky = createChild("div", "map-sky", sizer);
        sky.setAttribute("aria-hidden", "true");
        createMoodLayers(sky);                      // first, so stars, sun and moon lie on top of them
        createChild("div", "map-stars", sky);
        // two suns with fixed places, as in Version 4: morning on the right (east), evening on the left (west);
        // css/karte.css shows the one of the current mood
        createChild("div", "map-sun map-sun--aufgang", sky);
        createChild("div", "map-sun map-sun--untergang", sky);
        createChild("div", "map-moon", sky);
        var light = createChild("div", "map-light", sizer);   // over the whole map, also over the sky
        light.setAttribute("aria-hidden", "true");
        createMoodLayers(light);
    }

    /** Writes the numbers of the stage and the plate into CSS custom properties (used in css/karte.css). */
    function setDimensions() {
        var stageData = data.buehne;
        var planeData = data.ebene;
        var values = {
            "--stage-width": px(stageData.breite),
            "--stage-height": px(stageData.hoehe),
            "--perspective": px(stageData.perspektive),
            "--origin-x": px(stageData.ursprung[0]),
            "--origin-y": px(stageData.ursprung[1]),
            "--plane-left": px(planeData.links),
            "--plane-top": px(planeData.oben),
            "--plane-width": px(planeData.breite),
            "--plane-height": px(planeData.hoehe),
            "--pivot-x": px(planeData.drehpunkt[0]),
            "--pivot-y": px(planeData.drehpunkt[1]),
            "--tilt": planeData.kippung + "deg",
            "--untilt": (-planeData.kippung) + "deg",
            "--stretch": planeData.streckung,
            "--block-height": px(data.hoehen.block),
            "--palace-height": px(data.hoehen.schloss),
            "--palace-wall": data.schloss.wand,
            "--tree-width": px(data.baum.breite),
            "--tree-height": px(data.baum.hoehe)
        };
        for (var name in values) {
            sizer.style.setProperty(name, values[name]);   // the stage and the sky inherit them (2026-10-14)
        }
    }

    /** Scales the whole stage to the width of the frame (but not below MIN_SCALE). */
    function fitToFrame() {
        var width = frame.clientWidth;
        if (width === 0) {
            return;                                 // hidden: keep the last size
        }
        var scale = Math.max(width / data.buehne.breite, MIN_SCALE);
        sizer.style.setProperty("--scale", scale);      // for the stage and the sky band
        sizer.style.width = px(data.buehne.breite * scale);
        sizer.style.height = px(data.buehne.hoehe * scale);
    }

    /** A Quadrat was clicked (byKeyboard false) or chosen with Enter or Space (true): select it and tell the page. */
    function choose(code, byKeyboard) {
        waehlen(code);
        if (handlers.onSelect) {
            handlers.onSelect(code, byKeyboard);
        }
    }

    /* ---------------- colours ---------------- */

    /** Relative luminance of a colour like "#F3C2B5" (WCAG 2 formula): 0 = black, 1 = white. */
    function luminance(hex) {
        var channels = [];
        for (var i = 0; i < 3; i++) {
            var c = parseInt(hex.slice(1 + i * 2, 3 + i * 2), 16) / 255;
            channels.push(c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4));
        }
        return 0.2126 * channels[0] + 0.7152 * channels[1] + 0.0722 * channels[2];
    }

    /**
     * True if dark text is easier to read on this roof colour than white.
     * The text colour with the higher contrast ratio wins.
     */
    function needsDarkText(hex) {
        var l = luminance(hex);
        var contrastWhite = 1.05 / (l + 0.05);
        var contrastDark = (l + 0.05) / (luminance(TEXT_DARK) + 0.05);
        return contrastDark > contrastWhite;
    }

    /* ---------------- public interface ---------------- */

    /** Builds the map inside the container. options: { onSelect(code, byKeyboard), onHover(code or null) }. */
    function init(container, options) {
        data = window.KARTE_DATEN;
        if (!container || !data) {
            return;
        }
        handlers = options || {};
        elementsByCode = {};
        poolsByCode = {};
        entriesByCode = {};
        selected = null;
        walls = [];
        mood = null;
        moodsGlide = false;
        ghost = null;
        container.textContent = "";                 // remove whatever was there before
        container.classList.add("map-root");

        frame = createChild("div", "map-scroll", container);
        frame.setAttribute("role", "group");
        frame.setAttribute("aria-label", "3D-Karte der Mannheimer Quadrate");
        sizer = createChild("div", "map-sizer", frame);
        stage = createChild("div", "map-stage", sizer);
        plane = createChild("div", "map-plane", stage);
        pools = createChild("div", "map-pools", plane);   // first child: painted with the ground, under everything
        setDimensions();

        buildPalace();
        for (var i = 0; i < data.quadrate.length; i++) {
            var block = data.quadrate[i];
            elementsByCode[block.code] = buildBlock(block);
            entriesByCode[block.code] = block;
            updateLabel(block.code);
        }
        buildTreesAndLandmarks();
        buildSky();
        preloadGrounds();
        stimmung("tag");
        // js/filter.js sets the mood of the real time right after init(); that one should appear at once.
        // setTimeout(..., 0) runs the function after all scripts of the start have finished.
        window.setTimeout(function () {
            moodsGlide = true;
        }, 0);

        fitToFrame();
        if (resizeObserver) {
            resizeObserver.disconnect();            // init() called again: stop watching the old frame
        }
        if (window.ResizeObserver) {
            resizeObserver = new ResizeObserver(fitToFrame);
            resizeObserver.observe(frame);
        } else {
            window.addEventListener("resize", fitToFrame);
        }
        // on narrow screens start with the city centre (Kurpfalzstrasse) in the middle of the frame
        frame.scrollLeft = (frame.scrollWidth - frame.clientWidth) / 2;
    }

    /**
     * Colours whole buildings (roof and walls). Quadrate missing in the map get the default colours back.
     * Light colours (e.g. level 1 of every category) get the class is-tinted-light: dark code on the roof.
     * colours: e.g. { "G2": "#D23F27" }, or null for all default.
     * texts (optional): e.g. { "G2": "9 geöffnet" }, added to the accessible name of each Quadrat.
     */
    function faerben(colours, texts) {
        countTexts = texts || {};
        for (var code in elementsByCode) {
            var element = elementsByCode[code];
            var colour = colours ? colours[code] : null;
            if (colour) {
                element.style.setProperty("--tint", colour);
                element.classList.add("is-tinted");
                element.classList.toggle("is-tinted-light", needsDarkText(colour));
            } else {
                element.style.removeProperty("--tint");
                element.classList.remove("is-tinted", "is-tinted-light");
            }
            updateLabel(code);
        }
    }

    /**
     * Selects a Quadrat: it grows (CSS transition), the previous one shrinks back at the same time.
     * code: e.g. "O3"; null or an unknown code removes the selection. The chosen Quadrat gets
     * aria-current="true" (announced as "aktuell"); pressing it again does not unselect it.
     */
    function waehlen(code) {
        if (!elementsByCode[code]) {
            code = null;
        }
        if (selected === code) {
            return;
        }
        if (selected) {
            elementsByCode[selected].classList.remove("is-selected");
            elementsByCode[selected].removeAttribute("aria-current");
            poolsByCode[selected].classList.remove("is-lit");
        }
        selected = code;
        if (code) {
            elementsByCode[code].classList.add("is-selected");
            elementsByCode[code].setAttribute("aria-current", "true");
            poolsByCode[code].classList.add("is-lit");
        }
    }

    /**
     * Puts pins on the Quadrate in codes and removes all other pins. codes is a list (["G2", "O7"]: one red
     * pin each, as before), or, since 2026-10-13, an object { "G2": "essen", "O7": "trinken" }: then each pin
     * gets the colour of its category (classes cat-essen ... from css/style.css, see css/karte.css).
     * Since 2026-10-14 the value may also be a list of categories, one per saved place:
     * { "O7": ["trinken", "essen"] } puts two pins side by side on O7, each in its colour (at most MAX_PINS).
     */
    function markieren(codes) {
        var colours = {};                           // code -> list of categories (null = red)
        if (Array.isArray(codes)) {
            for (var i = 0; i < codes.length; i++) {
                colours[codes[i]] = [null];
            }
        } else if (codes) {
            for (var key0 in codes) {
                colours[key0] = Array.isArray(codes[key0]) ? codes[key0] : [codes[key0]];
            }
        }
        pinned = {};
        pinCategory = {};
        for (var key in colours) {
            if (elementsByCode[key]) {
                pinned[key] = true;
                pinCategory[key] = colours[key].slice(0, MAX_PINS);
            }
        }
        if (!plane) {
            return;                                 // map not built yet
        }
        var oldPins = plane.querySelectorAll(".map-pin");
        for (var j = 0; j < oldPins.length; j++) {
            oldPins[j].remove();
        }
        for (var code in pinned) {
            var anchor = entriesByCode[code].pin;
            var list = pinCategory[code];
            for (var p = 0; p < list.length; p++) {
                var pin = createChild("span", "map-pin" + (list[p] ? " cat-" + list[p] : ""), elementsByCode[code]);
                // several pins stand side by side, PIN_GAP apart, around the middle of the Quadrat
                var shift = (p - (list.length - 1) / 2) * PIN_GAP;
                pin.style.left = px(anchor[0] - 12 + shift);   // the tip of the 24 x 23 px pin is its bottom middle
                pin.style.top = px(anchor[1] - 23);
                if (anchor.length > 2) {
                    pin.style.setProperty("--pin-z", px(anchor[2]));   // open square: on top of its sign
                }
            }
        }
        for (var c in elementsByCode) {
            updateLabel(c);
        }
    }

    /**
     * Loads and prepares the four ground pictures (img/boden-<mood>.svg, about 400 KB each) right at the
     * start, so the first change to a new mood does not wait for its picture (from Version 4). decode() asks the
     * browser to prepare the picture for drawing in the background; older browsers without decode() just load it.
     */
    function preloadGrounds() {
        for (var name in LIGHT) {
            var picture = new Image();
            picture.src = "img/boden-" + name + ".svg";
            if (picture.decode) {
                picture.decode().catch(function () {});   // a failed preload is no problem: CSS loads it later
            }
        }
    }

    /** Removes the fading picture of the old mood (if there is one). */
    function removeGhost() {
        window.clearTimeout(ghostTimer);
        if (ghost) {
            ghost.remove();
            ghost = null;
        }
    }

    /**
     * Soft change of the mood (Version 6). Copies the frame of the map with everything in it (cloneNode(true)),
     * still in the old mood, and lays the copy exactly over the map. The map itself then switches to the new mood
     * at once, and css/karte.css lets the copy fade out in 0.9 s (div.map-ghost): the old picture dissolves into
     * the new one, the same look as the view transition of Version 4. The copy is a normal 3D map, so it keeps
     * the tilt; with the view transition some browsers drew the map upright for that moment.
     * If a copy is still fading (the slider was moved over two moods quickly), it simply goes on fading into the
     * newest mood; no second copy is made.
     */
    function fadeOut() {
        if (ghost) {
            return;
        }
        ghost = frame.cloneNode(true);
        ghost.classList.add("map-ghost");
        ghost.removeAttribute("role");              // only a picture: screen readers and the keyboard ignore it
        ghost.removeAttribute("aria-label");
        ghost.setAttribute("aria-hidden", "true");
        ghost.inert = true;
        frame.parentNode.appendChild(ghost);
        ghost.scrollLeft = frame.scrollLeft;        // phones: the same part of the map as the real one
        ghostTimer = window.setTimeout(removeGhost, FADE_MS + 100);
    }

    /**
     * Sets the time-of-day mood: "tag", "aufgang" (sunrise), "untergang" (sunset) or "nacht".
     * The colours come from css/karte.css (class mood-... on the frame of the map). Here every wall gets two numbers:
     *   --sun    how much it faces the sun or the moon, from 0 (not at all) to 1 (straight at it)
     *   --shade  how dark it is: walls turned away from the light are darker.
     * A wall's outside points in the direction (-sin(angle), cos(angle)) on the map (east, south); the scalar
     * product with the direction of the light says how much the two point the same way (shadeWalls()).
     * The first mood at the start and visitors who asked for less motion get the new mood at once; later changes
     * fade (fadeOut()).
     */
    function stimmung(name) {
        if (!LIGHT[name] || !stage) {
            return;
        }
        if (name === mood) {
            return;                                 // nothing changes: keep the walls as they are
        }
        var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        if (moodsGlide && !reduce) {
            fadeOut();                              // picture of the old mood, before anything changes
        }
        // The colours of the walls and roofs have no transition of their own (since Version 5), so they change at
        // once under the fading picture; Version 4 still had to switch transitions off for this moment.
        if (mood) {
            frame.classList.remove("mood-" + mood);
        }
        mood = name;
        frame.classList.add("mood-" + name);
        shadeWalls(LIGHT[name].direction, LIGHT[name].maxShade);
    }

    /**
     * Light and shade of every wall for a direction of the light [east, south] and the darkest shade (since
     * 2026-10-14 its own function).
     */
    function shadeWalls(direction, maxShade) {
        var length = Math.sqrt(direction[0] * direction[0] + direction[1] * direction[1]);
        var towardsX = direction[0] / length;
        var towardsY = direction[1] / length;
        for (var i = 0; i < walls.length; i++) {
            var radians = walls[i].angle * Math.PI / 180;
            var facing = -Math.sin(radians) * towardsX + Math.cos(radians) * towardsY;
            if (facing < 0) {
                facing = 0;                         // turned away from the light
            }
            var shade = (1 - facing) * maxShade;
            walls[i].element.style.setProperty("--sun", facing.toFixed(2));
            walls[i].element.style.setProperty("--shade", shade.toFixed(2));
        }
    }

    /** All 146 codes in the order A1 ... U6 (including M3a and M4a); also works before init(). */
    function codes() {
        var source = data || window.KARTE_DATEN;
        var list = [];
        if (!source) {
            return list;
        }
        for (var i = 0; i < source.quadrate.length; i++) {
            list.push(source.quadrate[i].code);
        }
        return list;
    }

    window.Karte = {
        init: init,
        faerben: faerben,
        waehlen: waehlen,
        markieren: markieren,
        stimmung: stimmung,
        codes: codes
    };
})();
